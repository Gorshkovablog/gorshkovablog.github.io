(() => {
  // Set to false to restore the previous full-page mobile reading layout.
  const INTERNAL_MOBILE_SCROLL=true;
  const internalScroll=INTERNAL_MOBILE_SCROLL && new URLSearchParams(location.search).get('bookScroll')!=='page';
  const story=document.querySelector('.book-story');
  const book=document.querySelector('.book-object');
  const flap=document.querySelector('.book-flap');
  const rail=document.querySelector('.book-rail');
  const stage=document.querySelector('.book-stage');
  const hero=document.querySelector('.hero-layer');
  const chapter=document.querySelector('.chapter-copy');
  const desktop=matchMedia('(min-width: 1001px) and (min-height: 650px)');
  const reduced=matchMedia('(prefers-reduced-motion: reduce)');
  const mobile=matchMedia('(max-width: 1000px)');
  const base=document.querySelector('.book-base');
  const paper=document.querySelector('.right-paper');
  const pencil=document.querySelector('.book-pencil');
  let mobileActive=false,active=false,pending=false;
  let mobileGeometry=null,measureNeeded=true,mobileOpening=null,lastFrame=0;
  let lastOpacity=-1,lastReadable=null,lastVisible=null;
  const clamp=(n,a=0,b=1)=>Math.max(a,Math.min(b,n));
  const smooth=n=>{n=clamp(n);return n*n*(3-2*n);};
  function display(layer,opacity,shift){
    layer.style.opacity=opacity;
    layer.style.transform=`translate(-50%,${shift}px)`;
    layer.style.visibility=opacity===0?'hidden':'visible';
    layer.inert=opacity===0;
  }
  function update(time){
    pending=false;
    if(mobileActive){updateMobile(time);return;}
    if(!active)return;
    const vh=innerHeight;
    const progress=clamp(-story.getBoundingClientRect().top/Math.max(1,story.offsetHeight-vh));
    const straighten=smooth(progress/.32);
    const opening=smooth((progress-.59)/.24);
    const height=book.offsetHeight;
    const firstScale=clamp(vh*.80/height,.9,1.1);
    const closedScale=clamp((vh-64)/height,.8,.94);
    const scale=firstScale+(closedScale-firstScale)*straighten+(1-closedScale)*opening;
    const startY=Math.max(190,300-vh*.12)+28;
    const closedY=Math.max(24,(vh-height*closedScale)/2);
    const openY=Math.max(24,(vh-height)/2);
    const y=startY+(closedY-startY)*straighten+(openY-closedY)*opening;
    const x=35*(1-straighten);
    book.style.transform=`translate3d(calc(-50% + ${x}px),${y}px,0) rotate(${-14*(1-straighten)}deg) scale(${scale})`;
    flap.style.transform=`rotateY(${-180*opening}deg)`;
    const heroOpacity=1-smooth((progress-.10)/.14);
    display(hero,heroOpacity,-45*(1-heroOpacity));
    const chapterOpacity=smooth((progress-.19)/.12)*(1-smooth((progress-.56)/.08));
    display(chapter,chapterOpacity,20*(1-chapterOpacity));
  }
  // Measure only when content or viewport geometry actually changes, never on scroll.
  function measureMobile(){
    const vh=innerHeight;
    const heroHeight=hero.offsetHeight;
    const finalTop=heroHeight+chapter.offsetHeight+12;
    const pageWidth=book.offsetWidth/2;
    const coverHeight=Math.min(pageWidth*1.48,internalScroll?vh*.78:760,760);
    book.style.setProperty('--mobile-cover-height',`${coverHeight}px`);
    const fullHeight=base.offsetHeight;
    const openStart=heroHeight+Math.min(180,vh*.22);
    const openEnd=Math.max(openStart+260,finalTop-vh*.15);
    mobileGeometry={vh,width:innerWidth,storyTop:scrollY+story.getBoundingClientRect().top,
      finalTop,openStart,openEnd};
    book.style.setProperty('--mobile-book-height',`${fullHeight}px`);
    const firstTop=heroHeight-85;
    rail.style.top=`${firstTop}px`;
    rail.style.height=`${finalTop-firstTop+fullHeight}px`;
    rail.style.setProperty('--mobile-pin-top',`${vh*.62}px`);
    story.style.setProperty('--mobile-about-top',`${openEnd+32}px`);
    story.style.height=`${finalTop+fullHeight+45}px`;
    stage.style.minHeight=`${finalTop+fullHeight+45}px`;
    measureNeeded=false;
  }
  function updateMobile(time){
    if(measureNeeded||!mobileGeometry)measureMobile();
    const g=mobileGeometry;
    const scroll=scrollY-g.storyTop;
    const targetOpening=smooth((scroll-g.openStart)/(g.openEnd-g.openStart));
    // Frame-rate-independent damping continues between scroll events.
    const dt=lastFrame?Math.min(64,Math.max(0,time-lastFrame)):16.67;
    const blend=1-Math.exp(-dt/70);
    if(mobileOpening===null)mobileOpening=targetOpening;
    else mobileOpening+=(targetOpening-mobileOpening)*blend;
    const moving=Math.abs(targetOpening-mobileOpening)>.0002;
    if(!moving)mobileOpening=targetOpening;
    // Vertical travel is native CSS sticky; JS only animates the cover.
    flap.style.setProperty('--mobile-flap',`${(-180*mobileOpening).toFixed(4)}deg`);
    const opacity=smooth((mobileOpening-.10)/.55);
    if(opacity!==lastOpacity){base.style.opacity=opacity;lastOpacity=opacity;}
    const readable=mobileOpening>=.8,visible=mobileOpening>.1;
    if(readable!==lastReadable){base.inert=!readable;lastReadable=readable;}
    if(visible!==lastVisible){paper.style.visibility=visible?'visible':'hidden';lastVisible=visible;}
    lastFrame=moving?time:0;
    if(moving)queue();
  }
  function queue(){if(!pending){pending=true;requestAnimationFrame(update);}}
  function configure(){
    measureNeeded=true;mobileGeometry=null;mobileOpening=null;lastFrame=0;
    lastOpacity=-1;lastReadable=null;lastVisible=null;
    active=desktop.matches&&!reduced.matches;
    mobileActive=mobile.matches&&!reduced.matches;
    document.documentElement.classList.toggle('mobile-ready',mobileActive);
    document.documentElement.classList.toggle('book-reader',mobileActive&&internalScroll);
    if(mobileActive&&internalScroll){paper.tabIndex=0;paper.setAttribute('role','region');paper.setAttribute('aria-label','Обо мне. Текст можно прокручивать внутри страницы книги');}
    else{paper.removeAttribute('tabindex');paper.removeAttribute('role');paper.removeAttribute('aria-label');}
    if(!mobileActive){
      story.style.height='';story.style.removeProperty('--mobile-about-top');stage.style.minHeight='';
      rail.style.top='';rail.style.height='';rail.style.removeProperty('--mobile-pin-top');
      book.style.top='';book.style.removeProperty('--mobile-y');flap.style.removeProperty('--mobile-flap');base.style.opacity='';base.inert=false;paper.style.visibility='';pencil.style.opacity='';
    }
    document.documentElement.classList.toggle('motion-ready',active);
    if(!active){
      book.style.transform='';flap.style.transform='';
      for(const layer of [hero,chapter]){layer.style.opacity='';layer.style.visibility='';layer.style.transform='';layer.inert=false;}
    }
    queue();
  }
  addEventListener('scroll',queue,{passive:true});
  addEventListener('resize',()=>{
    // Browser toolbar expansion is not a new layout. Keep the scroll timeline stable.
    if(mobileActive&&mobileGeometry&&innerWidth===mobileGeometry.width&&Math.abs(innerHeight-mobileGeometry.vh)<160)return;
    configure();
  },{passive:true});
  desktop.addEventListener('change',configure);
  reduced.addEventListener('change',configure);
  mobile.addEventListener('change',configure);
  document.fonts.ready.then(()=>{measureNeeded=true;queue();});
  const contentResize=new ResizeObserver(()=>{measureNeeded=true;queue();});
  contentResize.observe(hero);contentResize.observe(chapter);
  configure();
})();
